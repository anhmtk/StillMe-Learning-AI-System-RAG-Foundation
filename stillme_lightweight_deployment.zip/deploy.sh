#!/bin/bash
echo "🚀 StillMe VPS Deployment Script"
echo "=================================="

# Update system
echo "📦 Updating system packages..."
apt update && apt upgrade -y

# Install Python dependencies
echo "🐍 Installing Python dependencies..."
pip3 install -r requirements.txt

# Create StillMe directory
echo "📁 Creating StillMe directory..."
mkdir -p /opt/stillme
cp -r stillme_core /opt/stillme/
cp real_stillme_gateway.py /opt/stillme/
cp stable_ai_server.py /opt/stillme/
cp .env /opt/stillme/

# Set permissions
chmod +x /opt/stillme/real_stillme_gateway.py
chmod +x /opt/stillme/stable_ai_server.py

# Create systemd service for Gateway
echo "🔧 Creating Gateway service..."
cat > /etc/systemd/system/stillme-gateway.service << EOF
[Unit]
Description=StillMe AI Gateway
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/stillme
ExecStart=/usr/bin/python3 /opt/stillme/real_stillme_gateway.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Create systemd service for AI Server
echo "🔧 Creating AI Server service..."
cat > /etc/systemd/system/stillme-ai.service << EOF
[Unit]
Description=StillMe AI Server
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/stillme
ExecStart=/usr/bin/python3 /opt/stillme/stable_ai_server.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Enable and start services
echo "🚀 Starting StillMe services..."
systemctl daemon-reload
systemctl enable stillme-gateway
systemctl enable stillme-ai
systemctl start stillme-gateway
systemctl start stillme-ai

# Check status
echo "📊 Checking service status..."
systemctl status stillme-gateway --no-pager
systemctl status stillme-ai --no-pager

echo "✅ StillMe deployment completed!"
echo "🌐 Gateway: http://160.191.89.99:21568"
echo "🤖 AI Server: http://160.191.89.99:1216"
