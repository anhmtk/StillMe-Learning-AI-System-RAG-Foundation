def some_function_in_module():
    return 10 / 0
