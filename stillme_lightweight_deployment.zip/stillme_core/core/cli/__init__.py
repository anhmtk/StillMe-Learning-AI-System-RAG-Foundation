"""
StillMe CLI Package

Command-line interface for StillMe AI Framework and AgentDev system.
"""

from .main import app

__all__ = ["app"]
